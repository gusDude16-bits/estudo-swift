//
//  Aula_UIApp.swift
//  Aula UI
//
//  Created by Turma01-10 on 27/05/26.
//

import SwiftUI

@main
struct Aula_UIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
