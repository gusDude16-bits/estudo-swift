//
//  ContentView.swift
//  Entrar
//
//  Created by Turma01-10 on 27/05/26.
//

import SwiftUI

struct ContentView: View {
    @State private var mostrandoAlerta: Bool = false
    @State private var text: String = ""
    
    var body: some View {
        VStack {
            Text("Bem vindo, \(text != "" ? (text) : "Fulano")")
                .font(.largeTitle)
            TextField("Fulano", text: $text)
                .multilineTextAlignment(.center)
                .font(.title)
            ZStack {
                Image("MINE")
                    .resizable()
                    .opacity(0.23)
                    .blur(radius: 3)
                Image("Minecraft_Logo")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .zIndex(2)
                Image("Bloco")
                    .zIndex(1)
            }
            Button("Entrar") {
                mostrandoAlerta = true
            }
            .padding()
            .alert("ALERTA!", isPresented: $mostrandoAlerta) {
                Button("Vamos lá!", role: .cancel) {
                    
                }
            } message: {
                Text("Você irá iniciar o desafio da aula agora")
            }
        }
    }
}

#Preview {
    ContentView()
}
