//
//  ContentView.swift
//  D2
//
//  Created by Turma01-10 on 27/05/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack (spacing: 67) {
            Image("Clube_de_Regatas_do_Flamengo_logo 1")
                .resizable()
                .scaledToFill()
                .frame(width: 100, height: 100)
                .clipShape(Circle())
            VStack (spacing: 5){
                Text("HackaTruck")
                    .foregroundStyle(.red)
                Text("77 Universidades")
                    .foregroundStyle(.blue)
                Text("5 regiões do Brasil")
                    .foregroundStyle(.orange)
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
