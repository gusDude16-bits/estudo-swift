//
//  D2App.swift
//  D2
//
//  Created by Turma01-10 on 27/05/26.
//

import SwiftUI

@main
struct D2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
