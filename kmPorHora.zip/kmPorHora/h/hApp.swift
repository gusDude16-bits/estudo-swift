//
//  hApp.swift
//  h
//
//  Created by Turma01-10 on 28/05/26.
//

import SwiftUI

@main
struct hApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
