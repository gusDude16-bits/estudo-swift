//
//  ContentView.swift
//  h
//
//  Created by Turma01-10 on 28/05/26.
//

import SwiftUI

struct ContentView: View {
    @State private var distancia: Double = 0
    @State private var tempo: Double = 0
    @State private var imagem: String = "Pergunta"
    @State private var velocidade: Double = 0
    @State private var corDeFundo: Color = .cinzaEscuro
    var body: some View {
        ZStack {
            Color(corDeFundo)
                .ignoresSafeArea()
            VStack {
                Text("Digite a \(Text("distância").bold()) (km):")
                TextField("0", value: $distancia, format: .number)
                    .background(.white)
                    .multilineTextAlignment(.center)
                    .clipShape(.capsule)
                    .frame(width: 250)
                Text("Digite a \(Text("tempo").bold()) (h):")
                TextField("0", value: $tempo, format: .number)
                    .background(.white)
                    .multilineTextAlignment(.center)
                    .clipShape(.capsule)
                    .frame(width: 250)
                Button("Calcular") {
                    if tempo>0 && distancia > 0 {
                        velocidade = distancia / tempo
                        if velocidade >= 0 && velocidade < 10 {
                            imagem = "Tartaruga"
                            corDeFundo = .verdeClaro
                        } else if velocidade < 30 {
                            imagem = "Elefante"
                            corDeFundo = .azulClaro
                        } else if velocidade < 70 {
                            imagem = "Avestruz"
                            corDeFundo = .laranjaClaro
                        } else if velocidade < 90 {
                            imagem = "Leao"
                            corDeFundo = .amareloClaro
                        } else if velocidade >= 90 {
                            imagem = "Guepardo"
                            corDeFundo = .vermelhoClaro
                        }
                    } else {
                        velocidade = 0
                        imagem = "Pergunta"
                        corDeFundo = .cinzaEscuro
                    }
                }
                .buttonStyle(.bordered)
                .foregroundStyle(.orange)
                .background(.black)
                .controlSize(.regular)
                .clipShape(.rect(cornerRadius: 6))
                Text("\(velocidade, format: .number.precision(.fractionLength(2)))km/h")
                    .font(.largeTitle)
                    .padding()
                    .padding(.top, 50)
                Image("\(imagem)")
                    .resizable()
                    .clipShape(Circle())
                    .frame(width: 270, height: 270)
                    .padding(.bottom, 50)
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 300, height: 150)
                    HStack {
                        VStack {
                            Text("TARTARUGA")
                            Text("ELEFANTE")
                            Text("AVESTRUZ")
                            Text("LEÃO")
                            Text("GUEPARDO")
                        }
                        VStack {
                            Text("(0 - 9.9 km/h)")
                            Text("(10 - 29.9 km/h)")
                            Text("(30 - 69.9 km/h)")
                            Text("(70 - 89.9 km/h)")
                            Text("(90 - 120 km/h)")
                        }
                        VStack {
                            Circle()
                                .frame(width: 15)
                                .foregroundStyle(.verdeClaro)
                            Circle()
                                .frame(width: 15)
                                .foregroundStyle(.azulClaro)
                            Circle()
                                .frame(width: 15)
                                .foregroundStyle(.laranjaClaro)
                            Circle()
                                .frame(width: 15)
                                .foregroundStyle(.amareloClaro)
                            Circle()
                                .frame(width: 15)
                                .foregroundStyle(.vermelhoClaro)
                        }
                    } .foregroundStyle(.white)
                }
            }
            
        }
    }
}

#Preview {
    ContentView()
}
